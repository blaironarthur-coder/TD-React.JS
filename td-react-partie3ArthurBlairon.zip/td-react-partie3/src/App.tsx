import React, { useEffect, useState, useMemo } from "react";
import { SuperHero } from "./SuperHero";
import SuperHerosData from "./SuperHeros.json";

const App = () => {
  const [heroes, setHeroes] = useState<SuperHero[]>([]);
  const [query, setQuery] = useState<string>("");

  useEffect(() => {
    const data = (SuperHerosData as any).superheros || SuperHerosData;

    const heroesList: SuperHero[] = data.map(
      (h: any) => new SuperHero(h.id, h.name, h["id-api"], h.slug)
    );
    setHeroes(heroesList);
  }, []);

  const filteredHeroes = useMemo(() => {
    const q = query.trim().toLowerCase();
    return heroes.filter((h) => h.name.toLowerCase().includes(q));
  }, [heroes, query]);

  return (
    <main style={{ fontFamily: "system-ui", padding: 24 }}>
      <h1>Super Heroes App</h1>
      <p>Nombre total : {heroes.length}</p>

      {/* Champ de recherche */}
      <input
        type="text"
        placeholder="Rechercher un héros..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{
          padding: 8,
          borderRadius: 6,
          border: "1px solid #ccc",
          marginBottom: 16,
        }}
      />

      {/* Liste dynamique */}
      <ul>
        {filteredHeroes.map((hero) => (
          <li key={hero.id}>{hero.name}</li>
        ))}
      </ul>

      {/* Message si aucun résultat */}
      {filteredHeroes.length === 0 && (
        <p>Aucun super-héros trouvé pour « {query} ».</p>
      )}
    </main>
  );
};

export default App;
